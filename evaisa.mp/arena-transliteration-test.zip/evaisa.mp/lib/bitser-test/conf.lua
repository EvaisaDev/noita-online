function love.conf(t)
	t.version = "11.3"
	t.console = true
end