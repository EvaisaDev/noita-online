-- write your own!
-- data to be tested, repetitions, number of tries
return {}, 10000, 3