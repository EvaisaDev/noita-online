-- constants (color format is ARGB)
dofile_once("data/scripts/lib/utilities.lua")
BiomeMapSetSize( 70, 48 )
