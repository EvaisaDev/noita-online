

SpectatorMode = {

}

return SpectatorMode