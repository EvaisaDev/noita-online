arena_list = {
    {
        biome_map = "mods/evaisa.arena/files/scripts/world/map_arena.lua",
        pixel_scenes = "mods/evaisa.arena/files/biome/arena_scenes.xml",
        spawn_points = {
            {x = 0, y = 0}
        },
        zone_size = 600,
    }
}